const express=require("express")
const app=express();
const mongoose=require("mongoose");
port=8080;
const Listing=require("./models/listing.js");
const path= require("path");//for ejs
const { render } = require("ejs");
const methodOverride=require("method-override")//for override
const ejsMate=require("ejs-mate")


app.set("view engine","ejs"); //for ejs
app.set("views",path.join(__dirname,"views"));//for ejs
app.use(express.urlencoded({extended:true}))
app.use(methodOverride("_method"));//for override
app.engine('ejs',ejsMate)//this is for ejs-mate
app.use(express.static(path.join(__dirname,"/public")))



async function main(){

    await mongoose.connect('mongodb://127.0.0.1:27017/wanderlust');
}
main().then(()=>{
console.log("conect to db");
})
.catch((err)=>console.log(err))

// new route 
app.get("/listings/new",(req,res)=>{
    res.render("listings/new.ejs")
})

//create route
app.post("/listings",async(req,res)=>{
    let newListing =new Listing(req.body.listing);
    await newListing.save();
    res.redirect("/listings")
})

// For showing in home page  indexing
app.get("/listings",async(req,res)=>{
    let allListing=await Listing.find({ });
    res.render("./listings/index.ejs",{allListing});
    
});
// show route read 
app.get("/listings/:id",async (req,res)=>{
    let {id}=req.params
    let listing =await Listing.findById(id);
    res.render("listings/show.ejs",{listing})
})

// edit route 
app.get("/listings/:id/edit",async (req,res)=>{
    let {id}=req.params
    let listing =await Listing.findById(id);
    res.render("listings/edit.ejs",{listing})
})
// update 
app.put("/listings/:id",async (req,res)=>{
    let {id}=req.params
    await Listing.findByIdAndUpdate(id,{...req.body.listing});
    res.redirect(`/listings/${id}`)
})

app.delete("/listings/:id",async (req,res)=>{
    let {id}=req.params
    let delete_listing=await Listing.findByIdAndDelete(id);
    console.log(delete_listing);
    res.redirect("/listings")
})




app.get("/",(req,res)=>{
    res.send("i am root")
})
app.listen(port,()=>{
console.log("app is listening in port 8080")
})
