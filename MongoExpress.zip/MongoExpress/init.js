//mongoose conections
const mongoose = require('mongoose');

const Chat=require('./models/chat')

main().then(()=>console.log("connection sucessful"))
.catch(err => console.log(err));

async function main() {
  await mongoose.connect('mongodb://127.0.0.1:27017/whatapp');
}

let allChats=[{
    from:"gautam",
    to:"dhruv",
    msg:"sent me your exam paper",
    created_at:new Date(),
},
{
    from:"dhruv",
    to:"gautam",
    msg:"Done",
    created_at:new Date(),
},

{
    from:"pushkar",
    to:"gautam",
    msg:"Have you submited assignment",
    created_at:new Date(),
},

{
    from:"gautam",
    to:"Pushkar",
    msg:"I have submited assignment",
    created_at:new Date(),
},

{
    from:"gautam",
    to:"priya",   
    msg:"Good morning",
    created_at:new Date(),
},

]
Chat.insertMany(allChats)